## MARTFURY TEMPLATE - REACT VERSION
###### Version 1.2.0
### Installation
```bash
npm install
```
or Yarn
```bash
yarn install 
```
### Develope
```bash
yarn dev 
```